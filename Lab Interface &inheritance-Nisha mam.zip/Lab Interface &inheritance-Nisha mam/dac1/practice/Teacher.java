package com.dac1.practice;

 interface School{
	
 public final static String school ="KTHM";
	public abstract void studentDetail();
	public abstract void TeacherDetail();
}
 class Student implements School {
	 int studetId;
	 String studentName;
	 String studentClass;
	 	Student(int id,String name,String classroom)
	 	{
	 		studetId=id;
	 		studentName=name;
	 		studentClass=classroom;
	 		
	 	}
	@Override
	public void studentDetail() {
		System.out.println(studetId);
		System.out.println(studentName);
		System.out.println(studentClass);
		System.out.println("aa"+School.school);
		
	}

	@Override
	public void TeacherDetail() {
		// TODO Auto-generated method stub
		
	}
}
 class Teacher extends Student implements School {
	 int TeacherId;
	 String TeacherName;
	 String TeacherClass;
	 Teacher(int iid,String nname,String cclassroom,int id,String name,String classroom)
	 	{
		 super(iid, nname, cclassroom);
	 		TeacherId=id;
	 		TeacherName=name;
	 		TeacherClass=classroom;
	 		
	 	}
	@Override
	public void studentDetail() {
		super.studentDetail();
		// TODO Auto-generated method stub
		
	}
	@Override
	public void TeacherDetail() {
		this.studentDetail();
		System.out.println("*****************");
		System.out.println(TeacherId);
		System.out.println(TeacherName);
		System.out.println(TeacherClass);
		System.out.println("aa"+School.school);
				
	}
		public static void main(String[] args) {
		Teacher t=new Teacher(1, "MANOJ", "BE", 11, "Shiv", "BE");
		t.TeacherDetail();
			}

}
