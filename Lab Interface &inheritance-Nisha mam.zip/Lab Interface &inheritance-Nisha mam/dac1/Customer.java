package com.dac1;

public class Customer extends Bank {
	
	
	private String firstName;
	private	String lastName;
	private	String mobNo;
	

	

		
 public Customer(String fn, String ln, String mb, String bn, String bb, String addr) {
			 		super(bn, bb, addr);
			 		this.firstName=fn;
			 		this.lastName=ln;
			 		this.mobNo=mb;
		 }





		public void display()
		{
			System.out.println("****************************");

			 System.out.println("Customer Name :"+firstName);
				System.out.println("Customer Sur Name :"+lastName);
				System.out.println("Customer Mob no :"+mobNo);
				super.display();
				System.out.println("****************************");

			
			
		}
		
		
		
	
}
