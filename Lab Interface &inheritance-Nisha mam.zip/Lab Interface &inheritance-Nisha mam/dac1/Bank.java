package com.dac1;

public class Bank {
	
	protected String bankName;
	protected	String bankBranch;   
	private String address;
	
	
	

	public Bank(String bn, String bb, String addr) {
			this.bankName=bn;
			this.bankBranch=bb;
			this.address=addr;
	
	}




	public void display() {
		
		System.out.println("****************************");

		System.out.println("Bank Name :"+bankName);
		System.out.println("Bank Branch :"+bankBranch);
		System.out.println("Bank Address "+address);
		
	}
	
	
	

}
