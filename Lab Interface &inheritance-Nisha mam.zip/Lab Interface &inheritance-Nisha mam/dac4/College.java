package com.dac4;

public interface College {
	
	 final public static String college="CDAC Mumbai..";

}
