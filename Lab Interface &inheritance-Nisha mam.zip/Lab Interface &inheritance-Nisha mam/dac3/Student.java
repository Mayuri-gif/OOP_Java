package com.dac3;

public class Student  implements School
{
			private int rollNo;
			String firstName;
			String Lastname;
			int age;
		
		
			public Student(int rn, String fn, String ln, int a) {
					rollNo=rn;
					firstName=fn;
					Lastname=ln;
					age=a;
			
			}


			@Override
			public void StudentDetails() 
			{
				System.out.println("****************************");
				System.out.println("Student Id :"+rollNo);
				System.out.println("Student Name :"+firstName);
				System.out.println("Student Sur Name :"+Lastname);
				System.out.println("Student Age :"+age);
				System.out.println("Student College :"+School.school);
			
			
			
			}
			
		
			@Override
		public void TeacherDetails() 
		{
				
		}
		
	


}
