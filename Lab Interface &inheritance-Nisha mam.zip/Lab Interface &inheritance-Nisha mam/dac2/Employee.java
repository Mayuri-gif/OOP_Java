package com.dac6;

public class Employee {
	int EmpId;
	String EmpName;
	String Address;
	public Employee(int empId, String empName, String address) {
		
		EmpId = empId;
		EmpName = empName;
		Address = address;
	}
	
	void display()
	{
		System.out.println(EmpId);
		System.out.println(EmpName);
		System.out.println(Address);
	}
	
	
	

}
