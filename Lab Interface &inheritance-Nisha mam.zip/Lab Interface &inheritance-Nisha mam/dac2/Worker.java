package com.dac6;

import java.util.Scanner;

public class Worker extends Employee {

	public Worker(int empId, String empName, String address) {
		super(empId, empName, address);
	}
	void displayed()
	{
		System.out.println("hi Worker");
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("please Enter id,name,address");
		int a=sc.nextInt();
		String b=sc.next();
			String c=sc.next();
		Worker w=new Worker(a, b, c);
		w.display();
	}
}
